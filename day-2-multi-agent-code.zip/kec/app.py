"""Streamlit chat UI for the 3-node graph.

    streamlit run app.py

Keeps the conversation in session state and feeds the whole history back into
the graph, so `collect_history` has something real to work with on turn two.
"""

import asyncio
import os

import streamlit as st
from dotenv import load_dotenv
from langchain_core.messages import AIMessage, HumanMessage
from langfuse import get_client
from langfuse.langchain import CallbackHandler

from graph import DEFAULT_GEMINI_MODEL, MAX_RETRIES, build_graph

load_dotenv()

NODE_LABELS = {
    "collect_history": "Framing the task",
    "research": "Researching — Tavily web search + Geoapify MCP",
    "validate": "Validating the answer",
}

EXAMPLES = [
    "What are the coordinates of the Eiffel Tower, and what is the current visitor entry fee?",
    "Where is the Sydney Opera House, and what's the cheapest guided tour right now?",
    "What's at 1600 Pennsylvania Avenue, and what are its visiting hours?",
]


@st.cache_resource(show_spinner="Discovering MCP tools…")
def get_runtime():
    """One event loop and one compiled graph, reused across reruns.

    The graph is built async (MCP tool discovery is), and the MCP/HTTP clients
    it holds are bound to whichever loop created them — so we keep that loop
    alive and run every later query on it rather than spinning up a fresh one
    per `asyncio.run`.
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    graph = loop.run_until_complete(build_graph())
    return loop, graph


async def run_graph(graph, messages, status):
    """Stream the graph, reporting each node as it lands. Returns final state."""
    final = {}
    stream = graph.astream(
        {"messages": messages, "retries": 0},
        config={
            "callbacks": [CallbackHandler()],
            "run_name": "kec-3node-agent-streamlit",
        },
        stream_mode=["updates", "values"],
    )

    async for mode, chunk in stream:
        if mode == "values":
            final = chunk
            continue
        for node, update in chunk.items():
            status.write(f"**{NODE_LABELS.get(node, node)}**")
            if node == "validate":
                if update.get("complete"):
                    status.write("Verdict: complete ✅")
                else:
                    status.write(f"Verdict: incomplete — {update.get('gaps', '')}")
                    status.write("Sending it back for another pass…")

    return final


st.set_page_config(page_title="3-Node Research Agent", page_icon="🔎")
st.title("🔎 3-Node Research Agent")
st.caption("LangGraph · Gemini · Tavily web search · Geoapify remote MCP · Langfuse")

with st.sidebar:
    st.subheader("Setup")
    st.write(f"**Model** — `{os.environ.get('GEMINI_MODEL', DEFAULT_GEMINI_MODEL)}`")
    st.write(f"**Max validator retries** — {MAX_RETRIES}")
    st.markdown(
        "**Pipeline**\n\n"
        "1. `collect_history` — turns the conversation into one task string\n"
        "2. `research` — agent with Tavily + Geoapify MCP tools\n"
        "3. `validate` — checks every part is answered; can loop back once"
    )
    if st.button("Clear conversation", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    role = "user" if isinstance(message, HumanMessage) else "assistant"
    with st.chat_message(role):
        st.markdown(message.content)

if not st.session_state.messages:
    st.write("Try one of these:")
    for i, example in enumerate(EXAMPLES):
        if st.button(example, key=f"ex{i}", use_container_width=True):
            st.session_state.pending = example
            st.rerun()

question = st.chat_input("Ask something that needs a location and a live fact…")
if not question and "pending" in st.session_state:
    question = st.session_state.pop("pending")

if question:
    st.session_state.messages.append(HumanMessage(question))
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        try:
            loop, graph = get_runtime()
            with st.status("Working…", expanded=True) as status:
                result = loop.run_until_complete(
                    run_graph(graph, st.session_state.messages, status)
                )
                status.update(label="Done", state="complete", expanded=False)

            answer = result.get("answer", "")
            st.markdown(answer)
            st.session_state.messages.append(AIMessage(answer))

            passes = result.get("retries", 0)
            if result.get("complete"):
                st.caption(f"Validator: complete after {passes} pass(es)")
            else:
                st.caption(f"Validator: still incomplete after {passes} pass(es)")
                if result.get("gaps"):
                    st.warning(f"Remaining gaps: {result['gaps']}")
        except Exception as exc:  # surface the error instead of a blank page
            st.error(f"{type(exc).__name__}: {exc}")
        finally:
            get_client().flush()
