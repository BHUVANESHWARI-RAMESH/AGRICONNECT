# 3-Node LangGraph Agent — MCP + Tavily + Langfuse

A minimal reference showing LangChain 1.x `create_agent` inside a LangGraph
pipeline, with a **remote** MCP server as a tool source and Langfuse tracing.

```
START → collect_history → research → validate ─┬→ END
          ▲                                    │
          └──────── incomplete (once) ─────────┘
```

| Node | What it does |
|------|--------------|
| `collect_history` | Plain Python. Reads the message history and formulates a single task string. On a retry it appends the validator's gaps. |
| `research` | `create_agent` with **Tavily web search** + **Geoapify remote MCP** tools (`geocode_address`, `geocode_structured_address`, `reverse_geocode_coordinates`). |
| `validate` | `create_agent` with Tavily and `response_format=Verdict`. Decides whether the answer covers the whole question; can route back once. |

## Setup

```bash
uv venv --python 3.12
uv pip install -r requirements.txt
cp .env.example .env    # then fill in your keys
```

Keys needed: `GOOGLE_API_KEY` (Gemini, from
[AI Studio](https://aistudio.google.com/apikey)), `TAVILY_API_KEY`,
`GEOAPIFY_API_KEY`, and the Langfuse public/secret pair.

`GEMINI_MODEL` picks the model and defaults to `gemini-2.5-flash`.

## Run

### CLI

```bash
.venv/bin/python main.py "Where is the Sydney Opera House and what's on there this month?"
```

With no argument it runs a default question that exercises both tool families
(Geoapify for the coordinates, Tavily for the live pricing).

### Streamlit chat UI

```bash
.venv/bin/streamlit run app.py
```

Opens at http://localhost:8501. To pick a different port, or to skip the
first-run email prompt:

```bash
.venv/bin/streamlit run app.py --server.port 8502
.venv/bin/streamlit run app.py --server.headless true
```

The UI keeps the conversation in session state and feeds the whole history back
into the graph on each turn, so `collect_history` has real context from turn two
onwards. The sidebar shows the active model and retry budget, and "Clear
conversation" resets the history.

Traces appear in Langfuse under the run name `kec-3node-agent` (CLI) or
`kec-3node-agent-streamlit` (UI), with nested spans for each node, both agent
sub-graphs, and every tool call.

## Notes

- Everything is `async`, because MCP tool discovery
  (`MultiServerMCPClient.get_tools()`) is.
- Geoapify authenticates via a **URL query parameter**, not a header — so the
  key is part of the MCP endpoint URL and will show up in trace metadata for
  MCP spans. Fine locally; rotate/scope the key before sharing traces.
- `MAX_RETRIES` in `graph.py` controls how many times the validator may send
  work back. It is `1` — one retry, then the best answer is returned regardless.
