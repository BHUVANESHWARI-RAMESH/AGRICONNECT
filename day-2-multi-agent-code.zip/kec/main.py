"""CLI entrypoint: runs the 3-node graph once, with Langfuse tracing.

    python main.py "your question here"
"""

import asyncio
import sys

from dotenv import load_dotenv
from langchain_core.messages import HumanMessage
from langfuse import get_client
from langfuse.langchain import CallbackHandler

from graph import build_graph

DEFAULT_QUESTION = (
    "What are the coordinates of the Eiffel Tower, "
    "and what is the current visitor entry fee?"
)


async def main() -> None:
    load_dotenv()

    question = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_QUESTION
    langfuse_handler = CallbackHandler()

    try:
        graph = await build_graph()
        result = await graph.ainvoke(
            {"messages": [HumanMessage(question)], "retries": 0},
            config={
                "callbacks": [langfuse_handler],
                "run_name": "kec-3node-agent",
            },
        )

        print(f"\nQUESTION\n{question}")
        print(f"\nANSWER\n{result['answer']}")
        print(f"\nVALIDATOR  complete={result['complete']}  passes={result['retries']}")
        if result["gaps"]:
            print(f"remaining gaps: {result['gaps']}")
    finally:
        # Short-lived process: push the buffered spans before we exit.
        get_client().flush()


if __name__ == "__main__":
    asyncio.run(main())
