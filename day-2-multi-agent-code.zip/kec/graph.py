"""A 3-node LangGraph pipeline.

    collect_history  ->  research  ->  validate  -+-> END
          ^                                       |
          +------------- (incomplete) ------------+

Node 1 formulates a task from the conversation history.
Node 2 is a `create_agent` with Tavily web search + Geoapify remote MCP tools.
Node 3 is a `create_agent` validator that checks the answer really covers the
question, and can send the pipeline back around once.
"""

import os
from typing import Annotated, Literal, TypedDict

from langchain.agents import create_agent
from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_tavily import TavilySearch
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from pydantic import BaseModel, Field

MAX_RETRIES = 1

GEOAPIFY_MCP_URL = "https://api.geoapify.com/v1/mcp"

RESEARCH_PROMPT = """You are a research assistant. Answer the user's task fully.

Tools:
- `tavily_search` for general knowledge, current events, prices, opening hours,
  anything you need from the open web.
- The `geocode_*` / `reverse_geocode_*` tools (Geoapify) for anything involving
  addresses, place lookups, or latitude/longitude coordinates. Prefer these over
  web search for location data.

Use as many tools as the task needs. Answer every part of a multi-part question,
and cite the source URL for facts you got from web search."""

VALIDATOR_PROMPT = """You are a strict answer validator.

You are given a user's question and a candidate answer. Decide whether the
answer addresses *every* part of the question. You have `tavily_search` — use it
to spot-check any factual claim that looks doubtful or stale.

Mark `complete` false if any sub-question is unanswered, the answer is vague
where a specific fact was asked for, or a claim contradicts what you find.
When marking it false, describe the gaps concretely so a researcher knows
exactly what to go find next."""


class Verdict(BaseModel):
    """The validator's structured judgement."""

    complete: bool = Field(
        description="True only if every part of the user's question is answered."
    )
    gaps: str = Field(
        description="What is missing or unverified. Empty string when complete."
    )


class AgentState(TypedDict):
    """State carried across the three nodes."""

    messages: Annotated[list[AnyMessage], add_messages]
    task: str
    answer: str
    complete: bool
    gaps: str
    retries: int


DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"


def get_model() -> ChatGoogleGenerativeAI:
    """Gemini via the Developer API — just a model name and an API key."""
    return ChatGoogleGenerativeAI(
        model=os.environ.get("GEMINI_MODEL", DEFAULT_GEMINI_MODEL),
        google_api_key=os.environ["GOOGLE_API_KEY"],
        temperature=0,
        timeout=300.0,
    )


def _drop_unsupported(node):
    """Recursively remove keys Gemini's schema dialect doesn't accept."""
    if isinstance(node, dict):
        return {
            k: _drop_unsupported(v)
            for k, v in node.items()
            if k != "additionalProperties"
        }
    if isinstance(node, list):
        return [_drop_unsupported(v) for v in node]
    return node


def make_gemini_safe(tool):
    """Rewrite an MCP tool's JSON Schema into what Gemini will accept.

    Two incompatibilities show up with the Geoapify server:

    - A top-level `anyOf` of bare `required` clauses — how some MCP servers
      spell "at least one of these fields" (`geocode_structured_address` does).
      Valid JSON Schema, but Gemini only accepts `anyOf` as a *type* union and
      400s on `required` at that level. We strip the clause and restate it in
      the description, so the model still knows the rule even though the schema
      no longer enforces it.
    - `additionalProperties`, which Gemini ignores while logging a warning per
      occurrence. Dropping it changes nothing but quiets the output.
    """
    schema = tool.args_schema
    if not isinstance(schema, dict):
        return tool

    variants = schema.get("anyOf")
    if variants and all(set(v) <= {"required"} for v in variants):
        schema = {k: v for k, v in schema.items() if k != "anyOf"}
        fields = sorted({f for v in variants for f in v.get("required", [])})
        if fields:
            note = f"Provide at least one of: {', '.join(fields)}."
            tool.description = f"{(tool.description or '').strip()}\n\n{note}".strip()

    tool.args_schema = _drop_unsupported(schema)
    return tool

# how to use
# create_agent(model.., tools=load_tools(), sysprompt..)
# GEOAPIFY_MCP_URL = "https://api.geoapify.com/v1/mcp"
async def load_tools() -> list:
    """Tavily plus every tool the Geoapify MCP server advertises."""
    client = MultiServerMCPClient(
        {
            "geoapify": {
                "transport": "http",
                "url": f"{GEOAPIFY_MCP_URL}?apiKey={os.environ['GEOAPIFY_API_KEY']}",
            }
        }
    )
    mcp_tools = await client.get_tools()
    return [TavilySearch(max_results=5), *(make_gemini_safe(t) for t in mcp_tools)]


# --- Node 1 -----------------------------------------------------------------


def collect_history(state: AgentState) -> dict:
    """Turn the conversation (plus any validator feedback) into one task string."""
    messages = state["messages"]
    last_human = max(
        (i for i, m in enumerate(messages) if isinstance(m, HumanMessage)),
        default=-1,
    )
    question = messages[last_human].content if last_human >= 0 else ""

    parts = []
    prior = messages[:last_human]
    if prior:
        transcript = "\n".join(
            f"{'User' if isinstance(m, HumanMessage) else 'Assistant'}: {m.content}"
            for m in prior
        )
        parts.append(f"Conversation so far:\n{transcript}")

    parts.append(f"Task: {question}")

    if state.get("gaps"):
        parts.append(
            "A previous attempt was judged incomplete. Address specifically:\n"
            f"{state['gaps']}"
        )

    return {"task": "\n\n".join(parts)}


# --- Node 2 -----------------------------------------------------------------


def make_research_node(tools: list):
    """Build the research agent once, at graph-construction time."""
    agent = create_agent(
        get_model(),
        tools,
        system_prompt=RESEARCH_PROMPT,
        name="research_agent",
    )

    async def research(state: AgentState) -> dict:
        result = await agent.ainvoke(
            {"messages": [HumanMessage(state["task"])]}
        )
        # `.text` flattens Gemini's content blocks (text + thought signatures)
        # down to the plain string the validator and the CLI both want.
        answer = result["messages"][-1].text
        return {"answer": answer, "messages": [AIMessage(answer)]}

    return research


# --- Node 3 -----------------------------------------------------------------


def make_validator_node():
    agent = create_agent(
        get_model(),
        [TavilySearch(max_results=3)],
        system_prompt=VALIDATOR_PROMPT,
        response_format=Verdict,
        name="validator_agent",
    )

    async def validate(state: AgentState) -> dict:
        question = next(
            (
                m.content
                for m in reversed(state["messages"])
                if isinstance(m, HumanMessage)
            ),
            "",
        )
        result = await agent.ainvoke(
            {
                "messages": [
                    HumanMessage(
                        f"Question:\n{question}\n\nCandidate answer:\n{state['answer']}"
                    )
                ]
            }
        )
        verdict: Verdict = result["structured_response"]
        return {
            "complete": verdict.complete,
            "gaps": verdict.gaps,
            "retries": state["retries"] + 1,
        }

    return validate


def route(state: AgentState) -> Literal["collect_history", "__end__"]:
    if state["complete"] or state["retries"] > MAX_RETRIES:
        return END
    return "collect_history"


async def build_graph():
    """Load MCP tools, build both agents, and compile the graph."""
    tools = await load_tools()

    builder = StateGraph(AgentState)
    builder.add_node("collect_history", collect_history)
    builder.add_node("research", make_research_node(tools))
    builder.add_node("validate", make_validator_node())

    builder.add_edge(START, "collect_history")
    builder.add_edge("collect_history", "research")
    builder.add_edge("research", "validate")
    builder.add_conditional_edges("validate", route)

    return builder.compile()
